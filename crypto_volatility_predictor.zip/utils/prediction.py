def predict_volatility(model, df):
    prediction = model.predict(df)[0]
    return prediction
