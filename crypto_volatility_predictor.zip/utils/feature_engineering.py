import pandas as pd
import numpy as np

def create_features(df, custom_input=False):
    df = df.copy()
    df['log_return'] = np.log(df['Close'] / df['Close'].shift(1)).fillna(0)
    df['rolling_std'] = df['log_return'].rolling(window=3).std().fillna(0)
    return df[['Open', 'High', 'Low', 'Close', 'Volume', 'rolling_std']]
