from flask import Flask, render_template, request
import pandas as pd
import yfinance as yf
import pickle
from utils.feature_engineering import create_features
from utils.prediction import predict_volatility

app = Flask(__name__)
model = pickle.load(open('model/model.pkl', 'rb'))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.form['mode'] == 'live':
        df = yf.download('BTC-USD', period='7d', interval='1d')
        df = df[['Open', 'High', 'Low', 'Close', 'Volume']]
        features_df = create_features(df)
        result = predict_volatility(model, features_df.tail(1))
        return render_template('result.html', prediction=result, data=features_df.tail(1).to_dict())
    else:
        data = [float(request.form[col]) for col in ['Open', 'High', 'Low', 'Close', 'Volume']]
        df = pd.DataFrame([data], columns=['Open', 'High', 'Low', 'Close', 'Volume'])
        features_df = create_features(df, custom_input=True)
        result = predict_volatility(model, features_df)
        return render_template('result.html', prediction=result, data=features_df.to_dict(orient='records')[0])

if __name__ == '__main__':
    app.run(debug=True)
